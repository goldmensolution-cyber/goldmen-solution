import type { PageCollectionItemBase, DataCollectionItemBase } from '@nuxt/content'

declare module '@nuxt/content' {
   interface IndexCollectionItem extends PageCollectionItemBase {
    hero: {
    links: {
      label: string
      to: string
      icon?: string
      size?: ("xs" | "sm" | "md" | "lg" | "xl")
      trailing?: boolean
      target?: string
      color?: ("primary" | "secondary" | "neutral" | "error" | "warning" | "success" | "info")
      variant?: ("solid" | "outline" | "subtle" | "soft" | "ghost" | "link")
    }[]
    }
    sections: {
    title: string
    description: string
    id: string
    orientation?: ("vertical" | "horizontal")
    reverse?: boolean
    features: {
      title: string
      description: string
      icon: string
    }[]
    }[]
    features: {
    title: string
    description: string
    items: {
      title: string
      description: string
      icon: string
    }[]
    }
    testimonials: {
    title: string
    description: string
    headline?: string
    items: {
      quote: string
      user: {
      name: string
      description: string
      to: string
      target: string
      avatar: {
        src: string
        alt?: string
        loading?: ("lazy" | "eager")
        srcset?: string
      }
      }
    }[]
    }
    cta: {
    title: string
    description: string
    links: {
      label: string
      to: string
      icon?: string
      size?: ("xs" | "sm" | "md" | "lg" | "xl")
      trailing?: boolean
      target?: string
      color?: ("primary" | "secondary" | "neutral" | "error" | "warning" | "success" | "info")
      variant?: ("solid" | "outline" | "subtle" | "soft" | "ghost" | "link")
    }[]
    }
  }
  
   interface DocsCollectionItem extends PageCollectionItemBase {}
  
   interface PricingCollectionItem extends PageCollectionItemBase {
    plans: {
    title: string
    description: string
    price: {
      month: string
      year: string
    }
    billing_period: string
    billing_cycle: string
    button: {
      label: string
      to: string
      icon?: string
      size?: ("xs" | "sm" | "md" | "lg" | "xl")
      trailing?: boolean
      target?: string
      color?: ("primary" | "secondary" | "neutral" | "error" | "warning" | "success" | "info")
      variant?: ("solid" | "outline" | "subtle" | "soft" | "ghost" | "link")
    }
    features: string[]
    highlight?: boolean
    }[]
    logos: {
    title: string
    icons: string[]
    }
    faq: {
    title: string
    description: string
    items: {
      label: string
      content: string
    }[]
    }
  }
  
   interface BlogCollectionItem extends PageCollectionItemBase {}
  
   interface PostsCollectionItem extends PageCollectionItemBase {
    image: {
    src: string
    }
    authors: {
    name: string
    to: string
    avatar: {
      src: string
    }
    }[]
    date: string
    badge: {
    label: string
    }
  }
  
   interface ChangelogCollectionItem extends PageCollectionItemBase {}
  
   interface VersionsCollectionItem extends PageCollectionItemBase {
    title: string
    description: string
    date: string
    image: string
  }
  

  interface PageCollections {
    index: IndexCollectionItem
    docs: DocsCollectionItem
    pricing: PricingCollectionItem
    blog: BlogCollectionItem
    posts: PostsCollectionItem
    changelog: ChangelogCollectionItem
    versions: VersionsCollectionItem
  }

  interface Collections {
    index: IndexCollectionItem
    docs: DocsCollectionItem
    pricing: PricingCollectionItem
    blog: BlogCollectionItem
    posts: PostsCollectionItem
    changelog: ChangelogCollectionItem
    versions: VersionsCollectionItem
  }
}
