/// <reference types="@nuxt/ui" />
/// <reference types="@nuxt/content" />
/// <reference types="@nuxt/image" />
/// <reference types="@nuxt/eslint" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="nuxt-og-image" />
/// <reference types="@vueuse/nuxt" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../node_modules/.pnpm/@nuxt+vite-builder@4.4.2_@b_2151e984879e9eef36c5d5b47b28d5bf/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@4.4.2_@b_7c31d68e21cf0a582052cd7f45813e39/node_modules/@nuxt/nitro-server/dist/index.d.mts" />
/// <reference path="eslint-typegen.d.ts" />
/// <reference path="image/providers.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
