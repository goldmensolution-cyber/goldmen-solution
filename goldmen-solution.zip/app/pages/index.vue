<script setup lang="ts">
import HomeHero from '../components/HomeHero.vue'
import HomeServices from '../components/HomeServices.vue'
import HomeHowItWorks from '../components/HomeHowItWorks.vue'
import HomeClients from '../components/HomeClients.vue'
import HomeCTA from '../components/HomeCTA.vue'

useSeoMeta({
  title: 'Home',
  description: 'A practical service platform for Kenyan businesses that need reliable tools for bookings, payments, customers and teams.'
})
</script>

<template>
  <div>
    <HomeHero />
    <HomeServices />
    <HomeHowItWorks />
    <HomeClients />
    <HomeCTA />
  </div>
</template>
